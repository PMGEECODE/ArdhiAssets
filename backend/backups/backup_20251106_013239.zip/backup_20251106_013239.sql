--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Debian 17.5-1)
-- Dumped by pg_dump version 17.5 (Debian 17.5-1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: approvalstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.approvalstatus AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED',
    'CANCELLED'
);


--
-- Name: assetcategorytype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.assetcategorytype AS ENUM (
    'DEVICES',
    'LAND_REGISTER',
    'BUILDINGS_REGISTER',
    'MOTOR_VEHICLES_REGISTER',
    'OFFICE_EQUIPMENT',
    'FURNITURE_FITTINGS_EQUIPMENT',
    'PLANT_MACHINERY',
    'PORTABLE_ATTRACTIVE_ITEMS',
    'ICT_ASSETS'
);


--
-- Name: backupstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.backupstatus AS ENUM (
    'COMPLETED',
    'FAILED',
    'IN_PROGRESS',
    'RESTORING'
);


--
-- Name: backuptype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.backuptype AS ENUM (
    'FULL',
    'DATABASE',
    'FILES'
);


--
-- Name: permissionlevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.permissionlevel AS ENUM (
    'NONE',
    'READ',
    'WRITE',
    'ADMIN'
);


--
-- Name: userrole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.userrole AS ENUM (
    'ADMIN',
    'USER',
    'VIEWER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: approval_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_requests (
    id uuid NOT NULL,
    requester_id uuid NOT NULL,
    approver_id uuid,
    request_title character varying(120) NOT NULL,
    request_description text NOT NULL,
    status public.approvalstatus NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_at timestamp with time zone,
    approval_notes text
);


--
-- Name: apscheduler_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.apscheduler_jobs (
    id character varying(191) NOT NULL,
    next_run_time double precision,
    job_state bytea NOT NULL
);


--
-- Name: asset_category_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.asset_category_permissions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    granted_by uuid NOT NULL,
    category public.assetcategorytype NOT NULL,
    permission_level public.permissionlevel NOT NULL,
    is_active boolean NOT NULL,
    reason text,
    notes text,
    expires_at timestamp without time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid NOT NULL,
    user_id uuid,
    username character varying,
    action character varying NOT NULL,
    entity_type character varying,
    entity_id uuid,
    event_category character varying,
    role character varying,
    status character varying NOT NULL,
    old_values json,
    new_values json,
    details text,
    ip_address character varying,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE audit_logs; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_logs IS 'Comprehensive audit trail for compliance';


--
-- Name: backups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.backups (
    id uuid NOT NULL,
    filename character varying(255) NOT NULL,
    file_size integer NOT NULL,
    backup_type public.backuptype NOT NULL,
    status public.backupstatus NOT NULL,
    created_by character varying(120) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    error_message character varying,
    progress_percentage integer NOT NULL,
    progress_message character varying(255),
    encrypted boolean DEFAULT false,
    encrypted_password_hash character varying(255)
);


--
-- Name: TABLE backups; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.backups IS 'Database backup records and metadata';


--
-- Name: buildings_register; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.buildings_register (
    id uuid NOT NULL,
    description_name_of_building character varying NOT NULL,
    building_ownership character varying,
    category character varying,
    building_no character varying,
    institution_no character varying,
    nearest_town_shopping_centre character varying,
    street character varying,
    county character varying,
    sub_county character varying,
    division character varying,
    location character varying,
    sub_location character varying,
    lr_no character varying,
    size_of_land_ha numeric(10,4),
    ownership_status character varying,
    source_of_funds character varying,
    mode_of_acquisition character varying,
    date_of_purchase_or_commissioning timestamp without time zone,
    type_of_building character varying,
    designated_use character varying,
    estimated_useful_life integer,
    no_of_floors integer,
    plinth_area numeric(12,2),
    cost_of_construction_or_valuation numeric(15,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation_to_date numeric(15,2),
    net_book_value numeric(15,2),
    annual_rental_income numeric(15,2),
    support_files json,
    remarks character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: device_otp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_otp (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    device_id character varying NOT NULL,
    device_name character varying NOT NULL,
    encrypted_secret text NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used timestamp with time zone
);


--
-- Name: failed_login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.failed_login_attempts (
    id uuid NOT NULL,
    user_id uuid,
    username character varying(255),
    ip_address inet NOT NULL,
    attempted_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE failed_login_attempts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.failed_login_attempts IS 'Failed login tracking for brute force detection';


--
-- Name: furniture_equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.furniture_equipment (
    id uuid NOT NULL,
    asset_description character varying(255) NOT NULL,
    financed_by character varying(255) NOT NULL,
    serial_number character varying(100) NOT NULL,
    tag_number character varying(100) NOT NULL,
    make_model character varying(255) NOT NULL,
    pv_number character varying(100),
    original_location character varying(255),
    current_location character varying(255),
    responsible_officer character varying(255),
    delivery_installation_date timestamp with time zone,
    replacement_date timestamp with time zone,
    disposal_date timestamp with time zone,
    purchase_amount numeric(15,2) NOT NULL,
    depreciation_rate numeric(5,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation numeric(15,2),
    net_book_value numeric(15,2),
    disposal_value numeric(15,2),
    asset_condition character varying(50),
    notes text,
    created_by character varying(150),
    updated_by character varying(150),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: furniture_equipment_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.furniture_equipment_transfers (
    id uuid NOT NULL,
    furniture_equipment_id uuid NOT NULL,
    previous_owner character varying(255),
    assigned_to character varying(255) NOT NULL,
    location character varying(255),
    room_or_floor character varying(255),
    transfer_department character varying(255),
    transfer_location character varying(255) NOT NULL,
    transfer_room_or_floor character varying(255),
    transfer_reason text,
    transfer_date timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(150),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ict_asset_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ict_asset_transfers (
    id uuid NOT NULL,
    ict_asset_id uuid NOT NULL,
    previous_owner character varying(255),
    assigned_to character varying(255) NOT NULL,
    location character varying(255),
    room_or_floor character varying(255),
    transfer_department character varying(255),
    transfer_location character varying(255) NOT NULL,
    transfer_room_or_floor character varying(255),
    transfer_reason text,
    transfer_date timestamp without time zone NOT NULL,
    created_by character varying(150),
    created_at timestamp without time zone NOT NULL
);


--
-- Name: ict_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ict_assets (
    id uuid NOT NULL,
    asset_description character varying(255) NOT NULL,
    financed_by character varying(255) NOT NULL,
    serial_number character varying(100) NOT NULL,
    tag_number character varying(100) NOT NULL,
    make_model character varying(255) NOT NULL,
    pv_number character varying(100),
    asset_type character varying(100),
    specifications text,
    software_licenses text,
    warranty_expiry timestamp without time zone,
    ip_address character varying(45),
    mac_address character varying(17),
    operating_system character varying(100),
    original_location character varying(255),
    current_location character varying(255),
    responsible_officer character varying(255),
    delivery_installation_date timestamp without time zone,
    replacement_date timestamp without time zone,
    disposal_date timestamp without time zone,
    purchase_amount numeric(15,2) NOT NULL,
    depreciation_rate numeric(5,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation numeric(15,2),
    net_book_value numeric(15,2),
    disposal_value numeric(15,2),
    asset_condition character varying(50),
    notes text,
    previous_owner character varying(255),
    transfer_department character varying(255),
    transfer_location character varying(255),
    transfer_room_or_floor character varying(255),
    transfer_reason text,
    created_by character varying(150),
    updated_by character varying(150),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: land_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.land_assets (
    id uuid NOT NULL,
    description_of_land text NOT NULL,
    mode_of_acquisition character varying(100),
    category character varying(50),
    county character varying(100),
    sub_county character varying(100),
    division character varying(100),
    location character varying(200),
    sub_location character varying(200),
    nearest_town_location character varying(200),
    gps_coordinates character varying(100),
    polygon json,
    lr_certificate_no character varying(100),
    document_of_ownership character varying(200),
    proprietorship_details text,
    size_ha numeric(10,4),
    land_tenure character varying(50),
    surveyed character varying(20),
    acquisition_date timestamp with time zone,
    registration_date timestamp with time zone,
    disposal_date timestamp with time zone,
    change_of_use_date timestamp with time zone,
    disputed character varying(20),
    encumbrances text,
    planned_unplanned character varying(50),
    purpose_use_of_land text,
    acquisition_amount numeric(15,2),
    fair_value numeric(15,2),
    disposal_value numeric(15,2),
    annual_rental_income numeric(15,2),
    remarks text,
    created_by character varying(100),
    updated_by character varying(100),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mfa_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mfa_secrets (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    secret_encrypted character varying(255) NOT NULL,
    backup_codes character varying[] NOT NULL,
    enabled boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone
);


--
-- Name: TABLE mfa_secrets; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.mfa_secrets IS 'TOTP secrets and backup codes for two-factor authentication';


--
-- Name: motor_vehicles_register; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.motor_vehicles_register (
    id uuid NOT NULL,
    registration_number character varying NOT NULL,
    chassis_number character varying,
    engine_number character varying,
    tag_number character varying,
    make_model character varying,
    color character varying,
    asset_condition character varying,
    year_of_purchase character varying,
    pv_number character varying,
    financed_by character varying,
    amount numeric(15,2),
    depreciation_rate numeric(5,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation numeric(15,2),
    net_book_value numeric(15,2),
    date_of_disposal timestamp without time zone,
    disposal_value numeric(15,2),
    replacement_date timestamp without time zone,
    has_logbook character varying,
    responsible_officer character varying,
    original_location character varying,
    current_location character varying,
    notes character varying,
    image_urls json,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    message character varying(500) NOT NULL,
    link character varying(255),
    read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE notifications; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.notifications IS 'User notifications and alerts';


--
-- Name: office_equipment_register; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_equipment_register (
    id uuid NOT NULL,
    asset_description character varying(255) NOT NULL,
    financed_by character varying(255) NOT NULL,
    serial_number character varying(100) NOT NULL,
    tag_number character varying(100) NOT NULL,
    make_model character varying(255) NOT NULL,
    pv_number character varying(100),
    original_location character varying(255),
    current_location character varying(255),
    responsible_officer character varying(255),
    date_of_delivery timestamp without time zone,
    replacement_date timestamp without time zone,
    date_of_disposal timestamp without time zone,
    purchase_amount numeric(15,2) NOT NULL,
    depreciation_rate numeric(5,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation numeric(15,2),
    net_book_value numeric(15,2),
    disposal_value numeric(15,2),
    asset_condition character varying(50),
    notes text,
    created_by character varying(150),
    updated_by character varying(150),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: office_equipment_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.office_equipment_transfers (
    id uuid NOT NULL,
    office_equipment_id uuid NOT NULL,
    previous_owner character varying(255),
    assigned_to character varying(255) NOT NULL,
    location character varying(255),
    room_or_floor character varying(255),
    transfer_department character varying(255),
    transfer_location character varying(255) NOT NULL,
    transfer_room_or_floor character varying(255),
    transfer_reason text,
    transfer_date timestamp without time zone NOT NULL,
    created_by character varying(150),
    created_at timestamp without time zone NOT NULL
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id uuid NOT NULL,
    code character varying(100) NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE permissions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.permissions IS 'Granular permissions for access control';


--
-- Name: plant_machinery; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plant_machinery (
    id uuid NOT NULL,
    asset_description character varying(255) NOT NULL,
    financed_by character varying(255) NOT NULL,
    serial_number character varying(100) NOT NULL,
    tag_number character varying(100) NOT NULL,
    make_model character varying(255) NOT NULL,
    pv_number character varying(100),
    original_location character varying(255),
    current_location character varying(255),
    responsible_officer character varying(255),
    delivery_installation_date timestamp without time zone,
    replacement_date timestamp without time zone,
    disposal_date timestamp without time zone,
    purchase_amount numeric(15,2) NOT NULL,
    depreciation_rate numeric(5,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation numeric(15,2),
    net_book_value numeric(15,2),
    disposal_value numeric(15,2),
    asset_condition character varying(50),
    notes text,
    created_by character varying(150),
    updated_by character varying(150),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: plant_machinery_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plant_machinery_transfers (
    id uuid NOT NULL,
    plant_machinery_id uuid NOT NULL,
    previous_owner character varying(255),
    assigned_to character varying(255) NOT NULL,
    location character varying(255),
    room_or_floor character varying(255),
    transfer_department character varying(255),
    transfer_location character varying(255) NOT NULL,
    transfer_room_or_floor character varying(255),
    transfer_reason text,
    transfer_date timestamp without time zone NOT NULL,
    created_by character varying(150),
    created_at timestamp without time zone NOT NULL
);


--
-- Name: portable_item_transfers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portable_item_transfers (
    id uuid NOT NULL,
    portable_item_id uuid NOT NULL,
    previous_owner character varying(255),
    assigned_to character varying(255) NOT NULL,
    location character varying(255),
    room_or_floor character varying(255),
    transfer_department character varying(255),
    transfer_location character varying(255) NOT NULL,
    transfer_room_or_floor character varying(255),
    transfer_reason text,
    transfer_date timestamp without time zone NOT NULL,
    created_by character varying(150),
    created_at timestamp without time zone NOT NULL
);


--
-- Name: portable_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portable_items (
    id uuid NOT NULL,
    asset_description character varying(255) NOT NULL,
    financed_by character varying(255) NOT NULL,
    serial_number character varying(100) NOT NULL,
    tag_number character varying(100) NOT NULL,
    make_model character varying(255) NOT NULL,
    pv_number character varying(100),
    original_location character varying(255),
    current_location character varying(255),
    responsible_officer character varying(255),
    delivery_installation_date timestamp without time zone,
    replacement_date timestamp without time zone,
    disposal_date timestamp without time zone,
    purchase_amount numeric(15,2) NOT NULL,
    depreciation_rate numeric(5,2),
    annual_depreciation numeric(15,2),
    accumulated_depreciation numeric(15,2),
    net_book_value numeric(15,2),
    disposal_value numeric(15,2),
    asset_condition character varying(50),
    notes text,
    created_by character varying(150),
    updated_by character varying(150),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.refresh_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked boolean NOT NULL,
    device_info json,
    replaced_by_token_id uuid
);


--
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.refresh_tokens IS 'Refresh tokens with rotation and reuse detection';


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    role_id uuid NOT NULL,
    permission_id uuid NOT NULL
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone NOT NULL
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.roles IS 'User roles for RBAC system';


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_token_id uuid NOT NULL,
    ip_address inet,
    user_agent character varying(300),
    created_at timestamp with time zone NOT NULL,
    last_seen timestamp with time zone NOT NULL
);


--
-- Name: TABLE sessions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.sessions IS 'Active user sessions for device management';


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id uuid NOT NULL,
    key character varying(100) NOT NULL,
    value text NOT NULL,
    description character varying(255),
    updated_at timestamp with time zone,
    updated_by uuid
);


--
-- Name: TABLE system_settings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.system_settings IS 'Global system configuration settings';


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    default_permissions json,
    parent_role_id uuid,
    is_active boolean NOT NULL,
    is_system_role boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(255) NOT NULL,
    refresh_token_hash character varying(255),
    device_id character varying(100) NOT NULL,
    device_name character varying(255) NOT NULL,
    device_type character varying(50) NOT NULL,
    browser character varying(100) NOT NULL,
    browser_version character varying(50) NOT NULL,
    os character varying(100) NOT NULL,
    os_version character varying(50) NOT NULL,
    ip_address character varying(45) NOT NULL,
    user_agent text NOT NULL,
    is_active boolean NOT NULL,
    last_activity timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    invalidated_at timestamp with time zone
);


--
-- Name: TABLE user_sessions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_sessions IS 'Enhanced session tracking with device metadata';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    role public.userrole NOT NULL,
    failed_attempts integer NOT NULL,
    locked_until timestamp without time zone,
    two_factor_auth boolean NOT NULL,
    two_factor_secret character varying(255),
    two_factor_code character varying(10),
    two_factor_code_expires timestamp without time zone,
    password_expiration timestamp without time zone NOT NULL,
    reset_token character varying(100),
    reset_token_expiry timestamp without time zone,
    password_changed_at timestamp without time zone,
    requires_password_change boolean NOT NULL,
    previous_password_hash character varying(255),
    session_timeout integer NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    department character varying(100),
    personal_number character varying(20),
    last_login timestamp without time zone,
    deactivation_reason text,
    deactivated_at timestamp without time zone,
    email_notifications boolean NOT NULL,
    device_alerts boolean NOT NULL,
    security_alerts boolean NOT NULL,
    maintenance_alerts boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'Core user authentication table with account lockout, 2FA, and password lifecycle support';


--
-- Data for Name: approval_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_requests (id, requester_id, approver_id, request_title, request_description, status, created_at, updated_at, approved_at, approval_notes) FROM stdin;
\.


--
-- Data for Name: apscheduler_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.apscheduler_jobs (id, next_run_time, job_state) FROM stdin;
\.


--
-- Data for Name: asset_category_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.asset_category_permissions (id, user_id, granted_by, category, permission_level, is_active, reason, notes, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, username, action, entity_type, entity_id, event_category, role, status, old_values, new_values, details, ip_address, user_agent, "timestamp") FROM stdin;
b42771fd-a667-499c-aa2d-45727b54a9f1	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 18:00:37.304186+03
dfdd9c57-58ec-4ec7-9616-a31131ea5392	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_access_denied	backup	\N	\N	\N	success	\N	\N	Invalid backup token: 403: Token-user mismatch	\N	\N	2025-11-05 15:00:57.16104+03
eed89610-3d9c-47b2-b030-7c00ed5f8d63	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verification_failed	master_password	\N	\N	\N	success	\N	\N	No active master password found	127.0.0.1	\N	2025-11-05 15:01:03.041124+03
17a5b16a-740d-43e5-83d2-f0d8115581f1	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_failed	backup	\N	\N	\N	success	\N	\N	Invalid master password attempt	\N	\N	2025-11-05 15:01:03.077012+03
d9664be3-9541-43d8-b5f8-64610b8ea714	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 15:02:14.416687+03
554974c7-e86b-4da6-adaa-e130b2b5b702	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 15:02:14.43074+03
f824317b-463e-4c1b-b202-0d8d00d34ec7	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 15:02:27.046117+03
8abea8f4-fd10-45b7-bda2-7594ba75d7bf	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_deleted	backup	\N	\N	\N	success	\N	\N	{'filename': 'pending'}	\N	\N	2025-11-05 15:05:42.936652+03
f88277cb-2ffc-4a72-83ff-74ef4714ad45	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 15:05:47.183678+03
18387fc1-3b16-40fc-a417-1633fac0bfd1	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_180547.zip', 'size': 11377}	\N	\N	2025-11-05 15:05:47.581414+03
ab78435a-5924-4e4f-80e4-e734c7793c49	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_FAILED	auth	\N	system	admin	success	null	null	Invalid password	127.0.0.1	\N	2025-11-05 18:15:43.577217+03
bb21854c-6479-42a9-9906-949ea109c716	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 18:15:49.640055+03
342f2f4b-88c8-48c3-ae57-c9192bda8e8f	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_downloaded	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_180547.zip'}	\N	\N	2025-11-05 15:16:16.75665+03
2b6a6c53-de64-49d9-8b4e-17e6e9bbda99	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 15:20:30.916514+03
af0ca275-3383-417d-a326-8fd5ec7ee725	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_182030.zip', 'size': 11852}	\N	\N	2025-11-05 15:20:31.225916+03
3d5d6073-07f1-455d-a89e-a5eccb881193	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 15:30:42.250272+03
6c7d2ec7-c919-4b67-99d9-b7e596d1f9bb	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 15:30:42.259255+03
11f05844-eab7-4798-a737-aa393211b3a7	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 18:32:21.896051+03
64e503b0-324a-4986-8889-f08dad2b1c44	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 15:33:30.92995+03
25e8ac2f-3fae-41ba-90dc-582f7b7d3658	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 15:33:30.935259+03
aa3e5605-211a-45b5-84dd-288adfed89e2	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_FAILED	auth	\N	system	admin	success	null	null	Invalid password	127.0.0.1	\N	2025-11-05 22:03:50.518465+03
9bfe9552-17bb-48e6-9d78-3fc19dc014fe	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 22:04:13.659527+03
4517a647-4361-48f0-a76a-129c90a6860e	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 19:05:00.32249+03
e0507d4a-19f4-4ce0-a5ac-dbb4950d9061	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 19:05:00.330402+03
84c9a848-551d-445c-a63e-96edc4015844	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 19:05:45.549291+03
cc65e8c0-f847-4a6f-b85b-d5ecfbfbd8de	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_220545.zip', 'size': 12658}	\N	\N	2025-11-05 19:05:45.971613+03
9716ea57-9d89-4cec-a6fd-7a76b263466e	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_downloaded	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_220545.zip'}	\N	\N	2025-11-05 19:05:55.575021+03
27fc1e04-bd75-4c3a-ac8d-4a8d128ff2c6	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 22:17:43.609911+03
b5a6e458-bf32-48db-b351-9d54bb46a0aa	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 19:17:56.724403+03
77b47496-af53-4cd3-a4a7-6de7ab5e041b	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 19:17:56.738183+03
61b8694f-ada3-46ee-affa-5f195887695d	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 19:22:51.669407+03
c1346cd2-ff42-489f-ad81-3506ac34e9f4	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_222251.zip', 'size': 13136}	\N	\N	2025-11-05 19:22:52.015471+03
b609cc86-2a9e-4dfa-b3ce-e7c92fbdaa51	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 22:38:21.308513+03
c03e062c-03eb-4de0-b9ce-86ae50028fea	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 19:39:42.048658+03
16ad60f6-8d4e-4a86-a4e3-79a6c00c43c1	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_223942.zip', 'size': 13465}	\N	\N	2025-11-05 19:39:42.377606+03
e86bc64b-69f3-4fa1-9704-40559d402242	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 22:59:14.948954+03
f6a083f7-22c1-47a9-aaca-d0589a582fc7	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 19:59:27.325077+03
e440483f-e7de-45da-9435-5c801197e7d1	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_225927.zip', 'size': 13784}	\N	\N	2025-11-05 19:59:27.690615+03
8894941a-9701-44c2-a875-ab7677923ac0	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 19:59:35.325843+03
21b8d4c2-0f0d-4a24-96cc-eca44c3b99da	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_225935.zip', 'size': 13910}	\N	\N	2025-11-05 19:59:35.655841+03
3773cb8a-1f5d-4d89-9857-c785ed4ff0ea	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-05 23:17:55.171425+03
bf960d04-22c5-462e-b96d-a3224c14b777	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verification_failed	master_password	\N	\N	\N	success	\N	\N	✗ Master password verification failed (invalid password) (version 1)	127.0.0.1	\N	2025-11-05 20:18:06.291179+03
b66d1724-47ee-47a0-97c4-ba3870982071	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_failed	backup	\N	\N	\N	success	\N	\N	Invalid master password attempt	\N	\N	2025-11-05 20:18:06.318455+03
d2be41e8-60cb-44bb-b375-76527774bbec	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 20:18:11.340471+03
143e1bb7-520a-4abb-a5cb-e3952fb422ea	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 20:18:11.362112+03
8ba51209-dbee-415e-8269-cb12dcaec156	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 20:19:20.197511+03
00b51f03-989c-498a-9ff0-44a79cfadd3c	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_231920.zip', 'size': 14543}	\N	\N	2025-11-05 20:19:20.486182+03
bce293bc-79b0-4512-a8d4-fe4674adc155	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated	\N	\N	2025-11-05 20:20:11.452618+03
c45befef-cdd2-40eb-8979-fe889f6d0773	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251105_232011.zip', 'size': 14677}	\N	\N	2025-11-05 20:20:11.737317+03
9376eeff-8427-4075-8a70-dc5a19831b15	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_FAILED	auth	\N	system	admin	success	null	null	Invalid password	127.0.0.1	\N	2025-11-06 00:05:23.841518+03
cb922f4a-0d52-4492-be8d-9e353b91dace	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-06 00:05:31.440992+03
3cebc041-33d2-44aa-b923-b747ed8d0456	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-06 00:39:52.853075+03
c76581a3-ea1d-40a5-af4e-fc25a46b54de	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 21:40:11.168032+03
adea44d7-2e0a-46d2-8dfb-0d468cb05d5d	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 21:40:11.179042+03
4b51d033-349b-4004-af29-4e25780df737	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated (encrypted=False)	\N	\N	2025-11-05 21:48:24.833239+03
aefcb66a-78a2-4cd0-97dd-66858b46a341	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251106_004824.zip', 'size': 15533, 'encrypted': False}	\N	\N	2025-11-05 21:48:25.130708+03
aef00f3d-3a25-4bb9-a9bf-ab6193b86f3d	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated (encrypted=True)	\N	\N	2025-11-05 21:52:35.411216+03
c21e8fb9-5c53-4294-b97e-56b28c37653f	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_created	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251106_005235.enc', 'size': 21028, 'encrypted': True}	\N	\N	2025-11-05 21:52:35.635844+03
1e3071cf-7e9d-477b-8e40-ea2803d56d7e	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_downloaded	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251106_005235.enc', 'encrypted': true}	\N	\N	2025-11-05 21:52:59.729687+03
988847a0-043f-407e-a9b7-daa15e128788	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_downloaded	backup	\N	\N	\N	success	\N	\N	{'filename': 'backup_20251106_004824.zip'}	\N	\N	2025-11-05 21:53:03.444299+03
82127a71-9fc5-4637-83f5-9a15a7431133	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 7f6ee92e-3aaa-4147-ae45-11c39e3327a2	\N	\N	2025-11-05 21:53:13.561557+03
44203d2c-410a-462c-b6d1-f7e2fabc0dfe	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 7f6ee92e-3aaa-4147-ae45-11c39e3327a2	\N	\N	2025-11-05 21:53:56.56128+03
32c95100-0c74-46a6-ba61-50e3d66fa80d	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 9b43fd39-837e-4164-b9b9-d40d94469b04	\N	\N	2025-11-05 21:54:26.146293+03
e8440b93-ce59-4e02-8a33-37bf4c545000	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	backup_restore_failed	backup	\N	\N	\N	success	\N	\N	Restore failed: Database restore failed: ERROR:  type "approvalstatus" already exists\nERROR:  type "assetcategorytype" already exists\nERROR:  type "backupstatus" already exists\nERROR:  type "backuptype" already exists\nERROR:  type "permissionlevel" already exists\nERROR:  type "userrole" already exists\nERROR:  relation "approval_requests" already exists\nERROR:  relation "apscheduler_jobs" already exists\nERROR:  relation "asset_category_permissions" already exists\nERROR:  relation "audit_logs" already exists\nERROR:  relation "backups" already exists\nERROR:  relation "buildings_register" already exists\nERROR:  relation "device_otp" already exists\nERROR:  relation "failed_login_attempts" already exists\nERROR:  relation "furniture_equipment" already exists\nERROR:  relation "furniture_equipment_transfers" already exists\nERROR:  relation "ict_asset_transfers" already exists\nERROR:  relation "ict_assets" already exists\nERROR:  relation "land_assets" already exists\nERROR:  relation "mfa_secrets" already exists\nERROR:  relation "motor_vehicles_register" already exists\nERROR:  relation "notifications" already exists\nERROR:  relation "office_equipment_register" already exists\nERROR:  relation "office_equipment_transfers" already exists\nERROR:  relation "permissions" already exists\nERROR:  relation "plant_machinery" already exists\nERROR:  relation "plant_machinery_transfers" already exists\nERROR:  relation "portable_item_transfers" already exists\nERROR:  relation "portable_items" already exists\nERROR:  relation "refresh_tokens" already exists\nERROR:  relation "role_permissions" already exists\nERROR:  relation "roles" already exists\nERROR:  relation "sessions" already exists\nERROR:  relation "system_settings" already exists\nERROR:  relation "user_roles" already exists\nERROR:  relation "user_sessions" already exists\nERROR:  relation "users" already exists\nERROR:  duplicate key value violates unique constraint "audit_logs_pkey"\nDETAIL:  Key (id)=(b42771fd-a667-499c-aa2d-45727b54a9f1) already exists.\nCONTEXT:  COPY audit_logs, line 1\nERROR:  duplicate key value violates unique constraint "backups_pkey"\nDETAIL:  Key (id)=(09ccd8fa-e0ce-44c8-a59a-b835650c8f78) already exists.\nCONTEXT:  COPY backups, line 1\nERROR:  duplicate key value violates unique constraint "permissions_pkey"\nDETAIL:  Key (id)=(a2f02247-2c0e-40a7-a307-b31b176771ae) already exists.\nCONTEXT:  COPY permissions, line 1\nERROR:  duplicate key value violates unique constraint "uq_role_permission"\nDETAIL:  Key (role_id, permission_id)=(20bdc263-5f03-4fda-9bd0-1ed2659678a1, a2f02247-2c0e-40a7-a307-b31b176771ae) already exists.\nCONTEXT:  COPY role_permissions, line 1\nERROR:  duplicate key value violates unique constraint "roles_pkey"\nDETAIL:  Key (id)=(20bdc263-5f03-4fda-9bd0-1ed2659678a1) already exists.\nCONTEXT:  COPY roles, line 1\nERROR:  duplicate key value violates unique constraint "user_sessions_pkey"\nDETAIL:  Key (id)=(1d97c07e-36cf-4b9e-a7c4-04347be8311e) already exists.\nCONTEXT:  COPY user_sessions, line 1\nERROR:  duplicate key value violates unique constraint "users_pkey"\nDETAIL:  Key (id)=(88f8c5f0-f75c-4b1c-88de-9887fe02ff86) already exists.\nCONTEXT:  COPY users, line 1\nERROR:  multiple primary keys for table "approval_requests" are not allowed\nERROR:  multiple primary keys for table "apscheduler_jobs" are not allowed\nERROR:  multiple primary keys for table "asset_category_permissions" are not allowed\nERROR:  multiple primary keys for table "audit_logs" are not allowed\nCancel request sent\nERROR:  canceling statement due to user request\n	\N	\N	2025-11-05 21:55:36.775964+03
12577dcf-442c-43e0-b127-d8f2453fc20a	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_FAILED	auth	\N	system	admin	success	null	null	Invalid password	127.0.0.1	\N	2025-11-06 01:04:08.729908+03
221ee55b-52b4-41bd-9c01-518292ef1d35	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-06 01:04:13.572136+03
3bd06a35-a13d-46f4-b5ed-a388cb4589e5	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	\N	master_password_verified	master_password	\N	\N	\N	success	\N	\N	✓ Master password verification succeeded (version 1)	127.0.0.1	\N	2025-11-05 22:04:24.178882+03
b8c77bc1-2338-497a-8e7d-116a31543f45	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	master_password_verified	backup	\N	\N	\N	success	\N	\N	Master password verified, backup access granted	\N	\N	2025-11-05 22:04:24.189982+03
745a64bd-61e3-4016-97af-6f6731927067	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	CREATE	user	571f3341-8740-41dc-89fc-d25d5a444545	data_modification	admin	success	null	null	\N	127.0.0.1	\N	2025-11-06 01:05:23.479829+03
8a83da70-2512-4427-a308-8e664b8fb12f	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 7f6ee92e-3aaa-4147-ae45-11c39e3327a2	\N	\N	2025-11-05 22:07:42.248646+03
44a1d3ee-f6c2-46ea-b6d1-5e1348806cba	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 7f6ee92e-3aaa-4147-ae45-11c39e3327a2	\N	\N	2025-11-05 22:15:16.298341+03
aa96d73a-96e9-47ed-bfa0-711bd3b3d0a4	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	LOGIN_SUCCESS	auth	\N	system	admin	success	null	null	Login successful from Linux	127.0.0.1	\N	2025-11-06 01:26:57.784807+03
5b8638b0-3e14-4690-a0da-9cf34a06fde7	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 7f6ee92e-3aaa-4147-ae45-11c39e3327a2	\N	\N	2025-11-05 22:27:14.660014+03
9c6e0a7a-320c-4c17-8cad-3cc20f991c8c	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_restore_initiated	backup	\N	\N	\N	success	\N	\N	Database restore initiated from backup: 7f6ee92e-3aaa-4147-ae45-11c39e3327a2	\N	\N	2025-11-05 22:31:17.860794+03
17210a65-a703-44c4-bccf-3ca8b3277483	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	backup_initiated	backup	\N	\N	\N	success	\N	\N	Database backup initiated (encrypted=False)	\N	\N	2025-11-05 22:32:39.889914+03
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.backups (id, filename, file_size, backup_type, status, created_by, created_at, error_message, progress_percentage, progress_message, encrypted, encrypted_password_hash) FROM stdin;
09ccd8fa-e0ce-44c8-a59a-b835650c8f78	backup_20251105_180547.zip	11377	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 18:05:47.157811+03	\N	100	Backup completed successfully	f	\N
9b43fd39-837e-4164-b9b9-d40d94469b04	backup_20251105_182030.zip	11852	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 18:20:30.894587+03	\N	100	Backup completed successfully	f	\N
3e1a2fea-9979-4206-9295-6b98f21d00b5	backup_20251105_220545.zip	12658	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 22:05:45.51877+03	\N	100	Backup completed successfully	f	\N
7f6ee92e-3aaa-4147-ae45-11c39e3327a2	backup_20251106_005235.enc	21028	DATABASE	FAILED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-06 00:52:35.381812+03	Failed to extract backup: File is not a zip file	0	Restore failed: File is not a zip file	t	926065cfe661f3040d84ee847937cfd323b01a4de631fe07c8baa0a571cf109f
a64db918-a2a0-42ff-974e-1efa42222c91	backup_20251105_222251.zip	13136	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 22:22:51.643156+03	\N	100	Backup completed successfully	f	\N
029cfc88-395c-43f6-bf04-94e6694e0bc4	pending	0	DATABASE	IN_PROGRESS	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-06 01:32:39.865674+03	\N	10	Starting database dump...	f	\N
0f213af7-23fb-4128-bc51-8f495df4200f	backup_20251105_223942.zip	13465	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 22:39:42.011661+03	\N	100	Backup completed successfully	f	\N
b64b9078-279d-4ede-b284-d0ea18b56634	backup_20251105_225927.zip	13784	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 22:59:27.280794+03	\N	100	Backup completed successfully	f	\N
99707017-1530-4737-b85d-49f460b75091	backup_20251105_225935.zip	13910	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 22:59:35.306414+03	\N	100	Backup completed successfully	f	\N
03ebaaf3-c507-42c1-95de-7aa51cee19eb	backup_20251105_231920.zip	14543	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 23:19:20.164905+03	\N	100	Backup completed successfully	f	\N
11a25750-b466-43fb-aef2-405c1a9c8675	backup_20251105_232011.zip	14677	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-05 23:20:11.433728+03	\N	100	Backup completed successfully	f	\N
11da8546-4182-4115-ac8b-f4e863e087cc	backup_20251106_004824.zip	15533	DATABASE	COMPLETED	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2025-11-06 00:48:24.791612+03	\N	100	Backup completed successfully	f	\N
\.


--
-- Data for Name: buildings_register; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.buildings_register (id, description_name_of_building, building_ownership, category, building_no, institution_no, nearest_town_shopping_centre, street, county, sub_county, division, location, sub_location, lr_no, size_of_land_ha, ownership_status, source_of_funds, mode_of_acquisition, date_of_purchase_or_commissioning, type_of_building, designated_use, estimated_useful_life, no_of_floors, plinth_area, cost_of_construction_or_valuation, annual_depreciation, accumulated_depreciation_to_date, net_book_value, annual_rental_income, support_files, remarks, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: device_otp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_otp (id, user_id, device_id, device_name, encrypted_secret, is_active, created_at, last_used) FROM stdin;
\.


--
-- Data for Name: failed_login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.failed_login_attempts (id, user_id, username, ip_address, attempted_at) FROM stdin;
\.


--
-- Data for Name: furniture_equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.furniture_equipment (id, asset_description, financed_by, serial_number, tag_number, make_model, pv_number, original_location, current_location, responsible_officer, delivery_installation_date, replacement_date, disposal_date, purchase_amount, depreciation_rate, annual_depreciation, accumulated_depreciation, net_book_value, disposal_value, asset_condition, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: furniture_equipment_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.furniture_equipment_transfers (id, furniture_equipment_id, previous_owner, assigned_to, location, room_or_floor, transfer_department, transfer_location, transfer_room_or_floor, transfer_reason, transfer_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: ict_asset_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ict_asset_transfers (id, ict_asset_id, previous_owner, assigned_to, location, room_or_floor, transfer_department, transfer_location, transfer_room_or_floor, transfer_reason, transfer_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: ict_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ict_assets (id, asset_description, financed_by, serial_number, tag_number, make_model, pv_number, asset_type, specifications, software_licenses, warranty_expiry, ip_address, mac_address, operating_system, original_location, current_location, responsible_officer, delivery_installation_date, replacement_date, disposal_date, purchase_amount, depreciation_rate, annual_depreciation, accumulated_depreciation, net_book_value, disposal_value, asset_condition, notes, previous_owner, transfer_department, transfer_location, transfer_room_or_floor, transfer_reason, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: land_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.land_assets (id, description_of_land, mode_of_acquisition, category, county, sub_county, division, location, sub_location, nearest_town_location, gps_coordinates, polygon, lr_certificate_no, document_of_ownership, proprietorship_details, size_ha, land_tenure, surveyed, acquisition_date, registration_date, disposal_date, change_of_use_date, disputed, encumbrances, planned_unplanned, purpose_use_of_land, acquisition_amount, fair_value, disposal_value, annual_rental_income, remarks, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mfa_secrets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mfa_secrets (id, user_id, secret_encrypted, backup_codes, enabled, created_at, verified_at) FROM stdin;
\.


--
-- Data for Name: motor_vehicles_register; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.motor_vehicles_register (id, registration_number, chassis_number, engine_number, tag_number, make_model, color, asset_condition, year_of_purchase, pv_number, financed_by, amount, depreciation_rate, annual_depreciation, accumulated_depreciation, net_book_value, date_of_disposal, disposal_value, replacement_date, has_logbook, responsible_officer, original_location, current_location, notes, image_urls, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, user_id, message, link, read, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_equipment_register; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_equipment_register (id, asset_description, financed_by, serial_number, tag_number, make_model, pv_number, original_location, current_location, responsible_officer, date_of_delivery, replacement_date, date_of_disposal, purchase_amount, depreciation_rate, annual_depreciation, accumulated_depreciation, net_book_value, disposal_value, asset_condition, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: office_equipment_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.office_equipment_transfers (id, office_equipment_id, previous_owner, assigned_to, location, room_or_floor, transfer_department, transfer_location, transfer_room_or_floor, transfer_reason, transfer_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, code, description, created_at) FROM stdin;
a2f02247-2c0e-40a7-a307-b31b176771ae	users.create	Create users	2025-11-05 14:58:28.637555+03
730a4062-96be-41e1-9b95-38b65367cb45	users.read	Read users	2025-11-05 14:58:28.638067+03
7730674f-fbb4-4ce6-be07-3f352596b358	users.update	Update users	2025-11-05 14:58:28.638266+03
0f026241-b466-4892-950f-3db6042b3205	users.delete	Delete users	2025-11-05 14:58:28.63839+03
5047d390-c794-4859-8263-b4e58085f1ad	assets.create	Create assets	2025-11-05 14:58:28.638503+03
fc8d4256-884f-45ca-b4fa-03e38ccdf946	assets.read	Read assets	2025-11-05 14:58:28.638615+03
bf1008d8-b185-425b-9cc1-fb777d932b5d	assets.update	Update assets	2025-11-05 14:58:28.63872+03
7239f599-469c-433a-8946-f8a62aae8293	assets.delete	Delete assets	2025-11-05 14:58:28.638853+03
d40458b7-8002-49fc-a27d-361794d3eb52	assets.transfer	Transfer assets	2025-11-05 14:58:28.638956+03
ba09c465-a13f-403b-b406-d3251040adbd	approvals.create	Create approvals	2025-11-05 14:58:28.639069+03
6fbcb99a-8a61-45b1-9f84-9ca9c42e8cc9	approvals.read	Read approvals	2025-11-05 14:58:28.639168+03
d65e4872-a4af-4585-8752-6cbcdfb08b96	approvals.approve	Approve requests	2025-11-05 14:58:28.639268+03
f8d14c7d-4360-4fae-b358-f38e3f270935	approvals.reject	Reject requests	2025-11-05 14:58:28.639374+03
99653cf6-cbbb-4c53-90cb-544273aaa5f7	reports.read	Read reports	2025-11-05 14:58:28.639501+03
6a6a22d2-9e94-4b0d-aa98-6fa4068bc041	audit.read	Read audit logs	2025-11-05 14:58:28.639602+03
7fd68d49-49a4-4ff1-8959-0ab6d23a28cb	settings.manage	Manage system settings	2025-11-05 14:58:28.639699+03
\.


--
-- Data for Name: plant_machinery; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plant_machinery (id, asset_description, financed_by, serial_number, tag_number, make_model, pv_number, original_location, current_location, responsible_officer, delivery_installation_date, replacement_date, disposal_date, purchase_amount, depreciation_rate, annual_depreciation, accumulated_depreciation, net_book_value, disposal_value, asset_condition, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plant_machinery_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plant_machinery_transfers (id, plant_machinery_id, previous_owner, assigned_to, location, room_or_floor, transfer_department, transfer_location, transfer_room_or_floor, transfer_reason, transfer_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: portable_item_transfers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portable_item_transfers (id, portable_item_id, previous_owner, assigned_to, location, room_or_floor, transfer_department, transfer_location, transfer_room_or_floor, transfer_reason, transfer_date, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: portable_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portable_items (id, asset_description, financed_by, serial_number, tag_number, make_model, pv_number, original_location, current_location, responsible_officer, delivery_installation_date, replacement_date, disposal_date, purchase_amount, depreciation_rate, annual_depreciation, accumulated_depreciation, net_book_value, disposal_value, asset_condition, notes, created_by, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.refresh_tokens (id, user_id, token_hash, issued_at, expires_at, revoked, device_info, replaced_by_token_id) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
20bdc263-5f03-4fda-9bd0-1ed2659678a1	a2f02247-2c0e-40a7-a307-b31b176771ae
20bdc263-5f03-4fda-9bd0-1ed2659678a1	730a4062-96be-41e1-9b95-38b65367cb45
20bdc263-5f03-4fda-9bd0-1ed2659678a1	7730674f-fbb4-4ce6-be07-3f352596b358
20bdc263-5f03-4fda-9bd0-1ed2659678a1	0f026241-b466-4892-950f-3db6042b3205
20bdc263-5f03-4fda-9bd0-1ed2659678a1	5047d390-c794-4859-8263-b4e58085f1ad
20bdc263-5f03-4fda-9bd0-1ed2659678a1	fc8d4256-884f-45ca-b4fa-03e38ccdf946
20bdc263-5f03-4fda-9bd0-1ed2659678a1	bf1008d8-b185-425b-9cc1-fb777d932b5d
20bdc263-5f03-4fda-9bd0-1ed2659678a1	7239f599-469c-433a-8946-f8a62aae8293
20bdc263-5f03-4fda-9bd0-1ed2659678a1	d40458b7-8002-49fc-a27d-361794d3eb52
20bdc263-5f03-4fda-9bd0-1ed2659678a1	ba09c465-a13f-403b-b406-d3251040adbd
20bdc263-5f03-4fda-9bd0-1ed2659678a1	6fbcb99a-8a61-45b1-9f84-9ca9c42e8cc9
20bdc263-5f03-4fda-9bd0-1ed2659678a1	d65e4872-a4af-4585-8752-6cbcdfb08b96
20bdc263-5f03-4fda-9bd0-1ed2659678a1	f8d14c7d-4360-4fae-b358-f38e3f270935
20bdc263-5f03-4fda-9bd0-1ed2659678a1	99653cf6-cbbb-4c53-90cb-544273aaa5f7
20bdc263-5f03-4fda-9bd0-1ed2659678a1	6a6a22d2-9e94-4b0d-aa98-6fa4068bc041
20bdc263-5f03-4fda-9bd0-1ed2659678a1	7fd68d49-49a4-4ff1-8959-0ab6d23a28cb
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	730a4062-96be-41e1-9b95-38b65367cb45
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	5047d390-c794-4859-8263-b4e58085f1ad
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	fc8d4256-884f-45ca-b4fa-03e38ccdf946
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	bf1008d8-b185-425b-9cc1-fb777d932b5d
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	d40458b7-8002-49fc-a27d-361794d3eb52
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	6fbcb99a-8a61-45b1-9f84-9ca9c42e8cc9
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	d65e4872-a4af-4585-8752-6cbcdfb08b96
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	99653cf6-cbbb-4c53-90cb-544273aaa5f7
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	6a6a22d2-9e94-4b0d-aa98-6fa4068bc041
6f4d300c-acf8-4696-b1fd-3792a81c73e9	fc8d4256-884f-45ca-b4fa-03e38ccdf946
6f4d300c-acf8-4696-b1fd-3792a81c73e9	ba09c465-a13f-403b-b406-d3251040adbd
6f4d300c-acf8-4696-b1fd-3792a81c73e9	99653cf6-cbbb-4c53-90cb-544273aaa5f7
9faf808a-6f4e-476f-8cee-4b750cea66fb	fc8d4256-884f-45ca-b4fa-03e38ccdf946
9faf808a-6f4e-476f-8cee-4b750cea66fb	99653cf6-cbbb-4c53-90cb-544273aaa5f7
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, created_at) FROM stdin;
20bdc263-5f03-4fda-9bd0-1ed2659678a1	ADMIN	Administrator with full access	2025-11-05 14:58:28.64836+03
65c8e9b0-16ce-4c5e-99f3-cc9be70c0fc4	MANAGER	Manager with asset management access	2025-11-05 14:58:28.654936+03
6f4d300c-acf8-4696-b1fd-3792a81c73e9	USER	Regular user with limited access	2025-11-05 14:58:28.668043+03
9faf808a-6f4e-476f-8cee-4b750cea66fb	VIEWER	Viewer with read-only access	2025-11-05 14:58:28.674089+03
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, user_id, refresh_token_id, ip_address, user_agent, created_at, last_seen) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_settings (id, key, value, description, updated_at, updated_by) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (id, name, description, default_permissions, parent_role_id, is_active, is_system_role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (id, user_id, token_hash, refresh_token_hash, device_id, device_name, device_type, browser, browser_version, os, os_version, ip_address, user_agent, is_active, last_activity, created_at, expires_at, invalidated_at) FROM stdin;
1d97c07e-36cf-4b9e-a7c4-04347be8311e	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	0c5207701ebe94261dd637b70a48d0fa8c31db353c9b80e710378744f82e6c5e	eeb1178cb999337d8de07eaa5cf1b11608d41f606b4e22604dfd1445b7a76c2d	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 18:00:37.283796+03	2025-11-05 18:00:37.283796+03	2025-11-05 15:30:37.286307+03	\N
07bc995b-5459-4097-9372-b5ef943c89db	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	09f190267257ee335a040cb97e31e6006899503c3439a4c00c49ec7a7bf7eb75	7bd8c90a4e08b1854fe5ea74ce357ec2bd747fd80d56eead89163baa23329765	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 18:15:49.622913+03	2025-11-05 18:15:49.622913+03	2025-11-05 15:45:49.625153+03	\N
da625317-019d-42c3-bbcd-db3debe0752d	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	032e28d9398572bcb575371a7f59a6d1849c0490485e1fd43113ee7aefcb72b2	9649ede97457957df381653b248525421cb562cd91903cc22e742da3c0ae50bf	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 18:32:21.88826+03	2025-11-05 18:32:21.88826+03	2025-11-05 16:02:21.889788+03	\N
fbd33333-1da8-49fe-9edf-130261d8e0dc	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	e696909be18d344c75bd28bc3bf2880b007cb1bb406fba3746a965cf8f06977b	04b6f68bd13484a6bfd409757ec74f9d7d9899b68d0f313755c3b0b2da0ba069	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 22:04:13.64994+03	2025-11-05 22:04:13.64994+03	2025-11-05 19:34:13.651494+03	\N
a8b7bb8e-7724-465f-9418-417a0bdfabb6	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	659b49110cafc8cad68befcd1502e09e8b76f6a8f6d2ca42827a6d37a18c38a1	9574c381f95eeb06577eef4030cdcdc63651afabe4ed0c5e78082ccea8dc6dfc	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 22:17:43.59508+03	2025-11-05 22:17:43.59508+03	2025-11-05 19:47:43.596976+03	\N
a1001605-e28e-4f95-b462-f79a5365006b	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	133dc4d9e81d33e7da91ae595c5337975c872511277aabe9554e93cce82ddb64	67c424eab033a1a9c35980db6540149e20336ef23f01fb00fb397a881fdec182	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 22:38:21.270573+03	2025-11-05 22:38:21.270573+03	2025-11-05 20:08:21.293399+03	\N
57315bc2-d95a-44f6-9978-d91352b4e480	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	5a59536dfbabcfe6279b15aebb05e40a98581b8d194fb62e9c9d01988718dbef	700f3e18d70690152fc1493adf1f7e76862767d19c574e18b38c1368994e51c3	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 22:59:14.924575+03	2025-11-05 22:59:14.924575+03	2025-11-05 20:29:14.931416+03	\N
b621a759-71f5-45b7-8022-4fe00cd38a8d	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	3f21faee4f2f88d12ba6606900609f97d34d18e5d027ee96296afcef820a912d	eb75984f2a4d1728aa2a6ac57e878fa22b8a262a8fd9bfb926112e79c9a691f9	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-05 23:17:55.14504+03	2025-11-05 23:17:55.14504+03	2025-11-05 20:47:55.151271+03	\N
73e214c3-5526-4a61-a2be-7ed32064cf3f	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	5f693b370b62cad87caaa617a8ab9a0903e97c0effc790e3d706905e8208ece4	07f24f3e9939607f1d1f1386bf198b39bd5600f3c85bd5e3c90d126aae28ae73	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-06 00:05:31.424536+03	2025-11-06 00:05:31.424536+03	2025-11-05 21:35:31.427664+03	\N
d2cf9bff-d299-4257-9365-af40e971b40c	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	2032260dd7892574944acaf167def89434a00038fa3bc9f080cc5c5876df12b8	8c62a3a85d39a2c73ccd58de78828668fe6f602a64eee6b69239bb7b7a6f9045	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-06 00:39:52.842709+03	2025-11-06 00:39:52.842709+03	2025-11-05 22:09:52.844406+03	\N
410a4247-64cc-47dd-8e35-aa8d3cf8c2f4	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	8622b985938cdc657b0bf393d01cc9e5be5de0165f28e6bc394409062fee9d88	3e1bf927b818c0c251e7e504ccc0084b2b88883403d218acda6cf68d9109a8ab	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-06 01:04:13.557823+03	2025-11-06 01:04:13.557823+03	2025-11-05 22:34:13.563872+03	\N
e16fb27b-fc6a-44c2-8971-28ce16736133	88f8c5f0-f75c-4b1c-88de-9887fe02ff86	904f5e650bc4a0e54458663348da11209def0537fb030ca6d3481abbb15b88bf	ebf036498be1e87b7cc4d353669dbb52e9f2429938190da08cfc1b9ee4513c84	91ad55e8009b8b03	Linux	desktop	Chrome	141.0.0.0	Linux	Unknown	127.0.0.1	Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36	t	2025-11-06 01:26:57.77422+03	2025-11-06 01:26:57.77422+03	2025-11-05 22:56:57.775937+03	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, is_active, is_verified, role, failed_attempts, locked_until, two_factor_auth, two_factor_secret, two_factor_code, two_factor_code_expires, password_expiration, reset_token, reset_token_expiry, password_changed_at, requires_password_change, previous_password_hash, session_timeout, first_name, last_name, department, personal_number, last_login, deactivation_reason, deactivated_at, email_notifications, device_alerts, security_alerts, maintenance_alerts, created_at, updated_at) FROM stdin;
571f3341-8740-41dc-89fc-d25d5a444545	Famage	george.pussl@gmail.com	$2b$12$XozYadXST9VRw45Je/2iu.SrSa7jlj4bP/daTR7BzStAOjFbCCuYm	t	f	USER	0	\N	f	\N	\N	\N	2026-02-03 22:05:23.47397	\N	\N	\N	t	\N	30	PmG	tech	ICT	123212245452	\N	\N	\N	t	t	t	f	2025-11-06 01:05:23.195821	2025-11-06 01:05:23.195821
88f8c5f0-f75c-4b1c-88de-9887fe02ff86	admin	dummygeecode@gmail.com	$2b$12$7x8yPlFw8ybJROnzZz9YQOC1aCjyNFnMja5E3egoEYSNACpLg9mqy	t	t	ADMIN	0	\N	f	\N	\N	\N	2026-02-03 14:58:29.167151	\N	\N	\N	t	\N	30	System	Administrator	\N	\N	2025-11-05 22:26:57.764652	\N	\N	t	t	t	f	2025-11-05 14:58:28.715101	2025-11-06 01:26:57.493761
\.


--
-- Name: approval_requests approval_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_pkey PRIMARY KEY (id);


--
-- Name: apscheduler_jobs apscheduler_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.apscheduler_jobs
    ADD CONSTRAINT apscheduler_jobs_pkey PRIMARY KEY (id);


--
-- Name: asset_category_permissions asset_category_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_category_permissions
    ADD CONSTRAINT asset_category_permissions_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: buildings_register buildings_register_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buildings_register
    ADD CONSTRAINT buildings_register_pkey PRIMARY KEY (id);


--
-- Name: device_otp device_otp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_otp
    ADD CONSTRAINT device_otp_pkey PRIMARY KEY (id);


--
-- Name: failed_login_attempts failed_login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_login_attempts
    ADD CONSTRAINT failed_login_attempts_pkey PRIMARY KEY (id);


--
-- Name: furniture_equipment furniture_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.furniture_equipment
    ADD CONSTRAINT furniture_equipment_pkey PRIMARY KEY (id);


--
-- Name: furniture_equipment_transfers furniture_equipment_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.furniture_equipment_transfers
    ADD CONSTRAINT furniture_equipment_transfers_pkey PRIMARY KEY (id);


--
-- Name: ict_asset_transfers ict_asset_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ict_asset_transfers
    ADD CONSTRAINT ict_asset_transfers_pkey PRIMARY KEY (id);


--
-- Name: ict_assets ict_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ict_assets
    ADD CONSTRAINT ict_assets_pkey PRIMARY KEY (id);


--
-- Name: land_assets land_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.land_assets
    ADD CONSTRAINT land_assets_pkey PRIMARY KEY (id);


--
-- Name: mfa_secrets mfa_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_secrets
    ADD CONSTRAINT mfa_secrets_pkey PRIMARY KEY (id);


--
-- Name: mfa_secrets mfa_secrets_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_secrets
    ADD CONSTRAINT mfa_secrets_user_id_key UNIQUE (user_id);


--
-- Name: motor_vehicles_register motor_vehicles_register_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.motor_vehicles_register
    ADD CONSTRAINT motor_vehicles_register_pkey PRIMARY KEY (id);


--
-- Name: motor_vehicles_register motor_vehicles_register_registration_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.motor_vehicles_register
    ADD CONSTRAINT motor_vehicles_register_registration_number_key UNIQUE (registration_number);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: office_equipment_register office_equipment_register_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_equipment_register
    ADD CONSTRAINT office_equipment_register_pkey PRIMARY KEY (id);


--
-- Name: office_equipment_transfers office_equipment_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_equipment_transfers
    ADD CONSTRAINT office_equipment_transfers_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plant_machinery plant_machinery_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plant_machinery
    ADD CONSTRAINT plant_machinery_pkey PRIMARY KEY (id);


--
-- Name: plant_machinery_transfers plant_machinery_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plant_machinery_transfers
    ADD CONSTRAINT plant_machinery_transfers_pkey PRIMARY KEY (id);


--
-- Name: portable_item_transfers portable_item_transfers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portable_item_transfers
    ADD CONSTRAINT portable_item_transfers_pkey PRIMARY KEY (id);


--
-- Name: portable_items portable_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portable_items
    ADD CONSTRAINT portable_items_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: asset_category_permissions unique_user_category_permission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_category_permissions
    ADD CONSTRAINT unique_user_category_permission UNIQUE (user_id, category);


--
-- Name: furniture_equipment uq_furniture_serial; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.furniture_equipment
    ADD CONSTRAINT uq_furniture_serial UNIQUE (serial_number);


--
-- Name: furniture_equipment uq_furniture_tag; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.furniture_equipment
    ADD CONSTRAINT uq_furniture_tag UNIQUE (tag_number);


--
-- Name: land_assets uq_land_lr_certificate; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.land_assets
    ADD CONSTRAINT uq_land_lr_certificate UNIQUE (lr_certificate_no);


--
-- Name: role_permissions uq_role_permission; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT uq_role_permission PRIMARY KEY (role_id, permission_id);


--
-- Name: user_roles user_roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_name_key UNIQUE (name);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_token_hash_key UNIQUE (token_hash);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_approval_approver_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_approver_id ON public.approval_requests USING btree (approver_id);


--
-- Name: idx_approval_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_created_at ON public.approval_requests USING btree (created_at);


--
-- Name: idx_approval_requester_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_requester_id ON public.approval_requests USING btree (requester_id);


--
-- Name: idx_approval_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_approval_status ON public.approval_requests USING btree (status);


--
-- Name: idx_auditlog_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_action ON public.audit_logs USING btree (action);


--
-- Name: idx_auditlog_action_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_action_time ON public.audit_logs USING btree (action, "timestamp");


--
-- Name: idx_auditlog_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_entity ON public.audit_logs USING btree (entity_type, entity_id);


--
-- Name: idx_auditlog_entity_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_entity_action ON public.audit_logs USING btree (entity_type, action);


--
-- Name: idx_auditlog_event_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_event_category ON public.audit_logs USING btree (event_category);


--
-- Name: idx_auditlog_event_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_event_time ON public.audit_logs USING btree (event_category, "timestamp");


--
-- Name: idx_auditlog_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_role ON public.audit_logs USING btree (role);


--
-- Name: idx_auditlog_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_status ON public.audit_logs USING btree (status);


--
-- Name: idx_auditlog_status_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_status_time ON public.audit_logs USING btree (status, "timestamp");


--
-- Name: idx_auditlog_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_timestamp ON public.audit_logs USING btree ("timestamp");


--
-- Name: idx_auditlog_user_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_user_action ON public.audit_logs USING btree (user_id, action);


--
-- Name: idx_auditlog_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_auditlog_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_user_time ON public.audit_logs USING btree (user_id, "timestamp");


--
-- Name: idx_auditlog_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auditlog_username ON public.audit_logs USING btree (username);


--
-- Name: idx_backups_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_backups_created_at ON public.backups USING btree (created_at);


--
-- Name: idx_backups_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_backups_created_by ON public.backups USING btree (created_by);


--
-- Name: idx_backups_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_backups_status ON public.backups USING btree (status);


--
-- Name: idx_building_acquisition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_acquisition ON public.buildings_register USING btree (mode_of_acquisition, date_of_purchase_or_commissioning);


--
-- Name: idx_building_category_ownership; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_category_ownership ON public.buildings_register USING btree (category, building_ownership);


--
-- Name: idx_building_cost_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_cost_value ON public.buildings_register USING btree (cost_of_construction_or_valuation, net_book_value);


--
-- Name: idx_building_county_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_county_location ON public.buildings_register USING btree (county, location);


--
-- Name: idx_building_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_created_at ON public.buildings_register USING btree (created_at);


--
-- Name: idx_building_date_of_purchase; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_date_of_purchase ON public.buildings_register USING btree (date_of_purchase_or_commissioning);


--
-- Name: idx_building_depreciation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_depreciation ON public.buildings_register USING btree (annual_depreciation, accumulated_depreciation_to_date);


--
-- Name: idx_building_floors_area; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_floors_area ON public.buildings_register USING btree (no_of_floors, plinth_area);


--
-- Name: idx_building_funds_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_funds_status ON public.buildings_register USING btree (source_of_funds, ownership_status);


--
-- Name: idx_building_land_size; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_land_size ON public.buildings_register USING btree (size_of_land_ha);


--
-- Name: idx_building_lr_no; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_lr_no ON public.buildings_register USING btree (lr_no);


--
-- Name: idx_building_nearest_town; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_nearest_town ON public.buildings_register USING btree (nearest_town_shopping_centre);


--
-- Name: idx_building_rental; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_rental ON public.buildings_register USING btree (annual_rental_income);


--
-- Name: idx_building_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_search ON public.buildings_register USING btree (description_name_of_building, location, county);


--
-- Name: idx_building_street; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_street ON public.buildings_register USING btree (street);


--
-- Name: idx_building_type_use; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_type_use ON public.buildings_register USING btree (type_of_building, designated_use);


--
-- Name: idx_building_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_updated_at ON public.buildings_register USING btree (updated_at);


--
-- Name: idx_building_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_building_value ON public.buildings_register USING btree (net_book_value);


--
-- Name: idx_deviceotp_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deviceotp_active ON public.device_otp USING btree (is_active);


--
-- Name: idx_deviceotp_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deviceotp_created_at ON public.device_otp USING btree (created_at);


--
-- Name: idx_deviceotp_last_used; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deviceotp_last_used ON public.device_otp USING btree (last_used);


--
-- Name: idx_deviceotp_user_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_deviceotp_user_device ON public.device_otp USING btree (user_id, device_id);


--
-- Name: idx_expiration_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_expiration_status ON public.asset_category_permissions USING btree (expires_at, is_active);


--
-- Name: idx_failed_logins_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_logins_ip ON public.failed_login_attempts USING btree (ip_address);


--
-- Name: idx_failed_logins_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_logins_time ON public.failed_login_attempts USING btree (attempted_at);


--
-- Name: idx_failed_logins_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_logins_user_id ON public.failed_login_attempts USING btree (user_id);


--
-- Name: idx_failed_logins_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_failed_logins_username ON public.failed_login_attempts USING btree (username);


--
-- Name: idx_furniture_asset_description; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_asset_description ON public.furniture_equipment USING btree (asset_description);


--
-- Name: idx_furniture_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_created_at ON public.furniture_equipment USING btree (created_at);


--
-- Name: idx_furniture_current_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_current_location ON public.furniture_equipment USING btree (current_location);


--
-- Name: idx_furniture_replacement_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_replacement_date ON public.furniture_equipment USING btree (replacement_date);


--
-- Name: idx_furniture_responsible_officer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_responsible_officer ON public.furniture_equipment USING btree (responsible_officer);


--
-- Name: idx_furniture_transfer_asset_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_transfer_asset_date ON public.furniture_equipment_transfers USING btree (furniture_equipment_id, transfer_date);


--
-- Name: idx_furniture_transfer_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_transfer_assigned_to ON public.furniture_equipment_transfers USING btree (assigned_to);


--
-- Name: idx_furniture_transfer_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_transfer_created_at ON public.furniture_equipment_transfers USING btree (created_at);


--
-- Name: idx_furniture_transfer_transfer_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_furniture_transfer_transfer_location ON public.furniture_equipment_transfers USING btree (transfer_location);


--
-- Name: idx_land_acquisition_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_land_acquisition_date ON public.land_assets USING btree (acquisition_date);


--
-- Name: idx_land_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_land_category ON public.land_assets USING btree (category);


--
-- Name: idx_land_county; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_land_county ON public.land_assets USING btree (county);


--
-- Name: idx_land_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_land_created_at ON public.land_assets USING btree (created_at);


--
-- Name: idx_land_purpose_use; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_land_purpose_use ON public.land_assets USING btree (purpose_use_of_land);


--
-- Name: idx_land_sub_county; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_land_sub_county ON public.land_assets USING btree (sub_county);


--
-- Name: idx_location_responsible; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_location_responsible ON public.ict_assets USING btree (current_location, responsible_officer);


--
-- Name: idx_mfa_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mfa_enabled ON public.mfa_secrets USING btree (enabled);


--
-- Name: idx_mfa_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mfa_user_id ON public.mfa_secrets USING btree (user_id);


--
-- Name: idx_notifications_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_created_at ON public.notifications USING btree (created_at);


--
-- Name: idx_notifications_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_read ON public.notifications USING btree (read);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_office_transfer_asset_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_transfer_asset_date ON public.office_equipment_transfers USING btree (office_equipment_id, transfer_date);


--
-- Name: idx_office_transfer_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_transfer_assigned_to ON public.office_equipment_transfers USING btree (assigned_to);


--
-- Name: idx_office_transfer_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_office_transfer_location ON public.office_equipment_transfers USING btree (transfer_location);


--
-- Name: idx_permission_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_permission_code ON public.permissions USING btree (code);


--
-- Name: idx_permission_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_permission_level ON public.asset_category_permissions USING btree (permission_level);


--
-- Name: idx_plant_transfer_asset_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_plant_transfer_asset_date ON public.plant_machinery_transfers USING btree (plant_machinery_id, transfer_date);


--
-- Name: idx_plant_transfer_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_plant_transfer_assigned_to ON public.plant_machinery_transfers USING btree (assigned_to);


--
-- Name: idx_plant_transfer_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_plant_transfer_location ON public.plant_machinery_transfers USING btree (transfer_location);


--
-- Name: idx_portable_transfer_asset_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portable_transfer_asset_date ON public.portable_item_transfers USING btree (portable_item_id, transfer_date);


--
-- Name: idx_portable_transfer_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portable_transfer_assigned_to ON public.portable_item_transfers USING btree (assigned_to);


--
-- Name: idx_portable_transfer_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portable_transfer_location ON public.portable_item_transfers USING btree (transfer_location);


--
-- Name: idx_refresh_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: idx_refresh_revoked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_revoked ON public.refresh_tokens USING btree (revoked);


--
-- Name: idx_refresh_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_token_hash ON public.refresh_tokens USING btree (token_hash);


--
-- Name: idx_refresh_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_refresh_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: idx_role_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_name ON public.roles USING btree (name);


--
-- Name: idx_role_permission_permission_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permission_permission_id ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permission_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_permission_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: idx_sessions_last_seen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_last_seen ON public.sessions USING btree (last_seen);


--
-- Name: idx_sessions_refresh_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_refresh_token_id ON public.sessions USING btree (refresh_token_id);


--
-- Name: idx_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sessions_user_id ON public.sessions USING btree (user_id);


--
-- Name: idx_system_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: idx_transfer_asset_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_asset_date ON public.ict_asset_transfers USING btree (ict_asset_id, transfer_date);


--
-- Name: idx_transfer_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_assigned_to ON public.ict_asset_transfers USING btree (assigned_to);


--
-- Name: idx_transfer_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_transfer_location ON public.ict_asset_transfers USING btree (transfer_location);


--
-- Name: idx_user_category_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_category_active ON public.asset_category_permissions USING btree (user_id, category, is_active);


--
-- Name: idx_vehicle_asset_condition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_asset_condition ON public.motor_vehicles_register USING btree (asset_condition);


--
-- Name: idx_vehicle_chassis_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_chassis_number ON public.motor_vehicles_register USING btree (chassis_number);


--
-- Name: idx_vehicle_color; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_color ON public.motor_vehicles_register USING btree (color);


--
-- Name: idx_vehicle_current_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_current_location ON public.motor_vehicles_register USING btree (current_location);


--
-- Name: idx_vehicle_date_of_disposal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_date_of_disposal ON public.motor_vehicles_register USING btree (date_of_disposal);


--
-- Name: idx_vehicle_disposal_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_disposal_status ON public.motor_vehicles_register USING btree (date_of_disposal, net_book_value);


--
-- Name: idx_vehicle_engine_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_engine_number ON public.motor_vehicles_register USING btree (engine_number);


--
-- Name: idx_vehicle_location_condition; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_location_condition ON public.motor_vehicles_register USING btree (current_location, asset_condition);


--
-- Name: idx_vehicle_make_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_make_model ON public.motor_vehicles_register USING btree (make_model);


--
-- Name: idx_vehicle_make_model_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_make_model_lower ON public.motor_vehicles_register USING btree (lower((make_model)::text));


--
-- Name: idx_vehicle_purchase_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_purchase_value ON public.motor_vehicles_register USING btree (year_of_purchase, amount);


--
-- Name: idx_vehicle_reg_number_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_reg_number_lower ON public.motor_vehicles_register USING btree (lower((registration_number)::text));


--
-- Name: idx_vehicle_registration_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_registration_number ON public.motor_vehicles_register USING btree (registration_number);


--
-- Name: idx_vehicle_replacement_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_replacement_date ON public.motor_vehicles_register USING btree (replacement_date);


--
-- Name: idx_vehicle_year_of_purchase; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vehicle_year_of_purchase ON public.motor_vehicles_register USING btree (year_of_purchase);


--
-- Name: ix_apscheduler_jobs_next_run_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_apscheduler_jobs_next_run_time ON public.apscheduler_jobs USING btree (next_run_time);


--
-- Name: ix_asset_category_permissions_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_category_permissions_category ON public.asset_category_permissions USING btree (category);


--
-- Name: ix_asset_category_permissions_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_category_permissions_expires_at ON public.asset_category_permissions USING btree (expires_at);


--
-- Name: ix_asset_category_permissions_granted_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_category_permissions_granted_by ON public.asset_category_permissions USING btree (granted_by);


--
-- Name: ix_asset_category_permissions_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_category_permissions_is_active ON public.asset_category_permissions USING btree (is_active);


--
-- Name: ix_asset_category_permissions_permission_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_category_permissions_permission_level ON public.asset_category_permissions USING btree (permission_level);


--
-- Name: ix_asset_category_permissions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_asset_category_permissions_user_id ON public.asset_category_permissions USING btree (user_id);


--
-- Name: ix_buildings_register_building_no; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_building_no ON public.buildings_register USING btree (building_no);


--
-- Name: ix_buildings_register_building_ownership; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_building_ownership ON public.buildings_register USING btree (building_ownership);


--
-- Name: ix_buildings_register_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_category ON public.buildings_register USING btree (category);


--
-- Name: ix_buildings_register_county; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_county ON public.buildings_register USING btree (county);


--
-- Name: ix_buildings_register_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_created_at ON public.buildings_register USING btree (created_at);


--
-- Name: ix_buildings_register_date_of_purchase_or_commissioning; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_date_of_purchase_or_commissioning ON public.buildings_register USING btree (date_of_purchase_or_commissioning);


--
-- Name: ix_buildings_register_description_name_of_building; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_description_name_of_building ON public.buildings_register USING btree (description_name_of_building);


--
-- Name: ix_buildings_register_designated_use; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_designated_use ON public.buildings_register USING btree (designated_use);


--
-- Name: ix_buildings_register_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_id ON public.buildings_register USING btree (id);


--
-- Name: ix_buildings_register_institution_no; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_institution_no ON public.buildings_register USING btree (institution_no);


--
-- Name: ix_buildings_register_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_location ON public.buildings_register USING btree (location);


--
-- Name: ix_buildings_register_lr_no; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_lr_no ON public.buildings_register USING btree (lr_no);


--
-- Name: ix_buildings_register_nearest_town_shopping_centre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_nearest_town_shopping_centre ON public.buildings_register USING btree (nearest_town_shopping_centre);


--
-- Name: ix_buildings_register_type_of_building; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_buildings_register_type_of_building ON public.buildings_register USING btree (type_of_building);


--
-- Name: ix_device_otp_device_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_device_otp_device_id ON public.device_otp USING btree (device_id);


--
-- Name: ix_device_otp_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_device_otp_is_active ON public.device_otp USING btree (is_active);


--
-- Name: ix_device_otp_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_device_otp_user_id ON public.device_otp USING btree (user_id);


--
-- Name: ix_furniture_equipment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_furniture_equipment_id ON public.furniture_equipment USING btree (id);


--
-- Name: ix_furniture_equipment_transfers_assigned_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_furniture_equipment_transfers_assigned_to ON public.furniture_equipment_transfers USING btree (assigned_to);


--
-- Name: ix_furniture_equipment_transfers_furniture_equipment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_furniture_equipment_transfers_furniture_equipment_id ON public.furniture_equipment_transfers USING btree (furniture_equipment_id);


--
-- Name: ix_furniture_equipment_transfers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_furniture_equipment_transfers_id ON public.furniture_equipment_transfers USING btree (id);


--
-- Name: ix_ict_asset_transfers_ict_asset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ict_asset_transfers_ict_asset_id ON public.ict_asset_transfers USING btree (ict_asset_id);


--
-- Name: ix_ict_asset_transfers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ict_asset_transfers_id ON public.ict_asset_transfers USING btree (id);


--
-- Name: ix_ict_asset_transfers_transfer_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ict_asset_transfers_transfer_date ON public.ict_asset_transfers USING btree (transfer_date);


--
-- Name: ix_ict_assets_current_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ict_assets_current_location ON public.ict_assets USING btree (current_location);


--
-- Name: ix_ict_assets_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ict_assets_id ON public.ict_assets USING btree (id);


--
-- Name: ix_ict_assets_responsible_officer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ict_assets_responsible_officer ON public.ict_assets USING btree (responsible_officer);


--
-- Name: ix_ict_assets_serial_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ict_assets_serial_number ON public.ict_assets USING btree (serial_number);


--
-- Name: ix_ict_assets_tag_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_ict_assets_tag_number ON public.ict_assets USING btree (tag_number);


--
-- Name: ix_land_assets_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_land_assets_id ON public.land_assets USING btree (id);


--
-- Name: ix_land_assets_lr_certificate_no; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_land_assets_lr_certificate_no ON public.land_assets USING btree (lr_certificate_no);


--
-- Name: ix_office_equipment_register_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_office_equipment_register_id ON public.office_equipment_register USING btree (id);


--
-- Name: ix_office_equipment_transfers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_office_equipment_transfers_id ON public.office_equipment_transfers USING btree (id);


--
-- Name: ix_office_equipment_transfers_office_equipment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_office_equipment_transfers_office_equipment_id ON public.office_equipment_transfers USING btree (office_equipment_id);


--
-- Name: ix_office_equipment_transfers_transfer_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_office_equipment_transfers_transfer_date ON public.office_equipment_transfers USING btree (transfer_date);


--
-- Name: ix_permissions_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_permissions_code ON public.permissions USING btree (code);


--
-- Name: ix_plant_machinery_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_plant_machinery_id ON public.plant_machinery USING btree (id);


--
-- Name: ix_plant_machinery_transfers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_plant_machinery_transfers_id ON public.plant_machinery_transfers USING btree (id);


--
-- Name: ix_plant_machinery_transfers_plant_machinery_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plant_machinery_transfers_plant_machinery_id ON public.plant_machinery_transfers USING btree (plant_machinery_id);


--
-- Name: ix_plant_machinery_transfers_transfer_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_plant_machinery_transfers_transfer_date ON public.plant_machinery_transfers USING btree (transfer_date);


--
-- Name: ix_portable_item_transfers_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_portable_item_transfers_id ON public.portable_item_transfers USING btree (id);


--
-- Name: ix_portable_item_transfers_portable_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portable_item_transfers_portable_item_id ON public.portable_item_transfers USING btree (portable_item_id);


--
-- Name: ix_portable_item_transfers_transfer_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_portable_item_transfers_transfer_date ON public.portable_item_transfers USING btree (transfer_date);


--
-- Name: ix_portable_items_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_portable_items_id ON public.portable_items USING btree (id);


--
-- Name: ix_refresh_tokens_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_expires_at ON public.refresh_tokens USING btree (expires_at);


--
-- Name: ix_refresh_tokens_replaced_by_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_refresh_tokens_replaced_by_token_id ON public.refresh_tokens USING btree (replaced_by_token_id);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_system_settings_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_system_settings_key ON public.system_settings USING btree (key);


--
-- Name: ix_user_roles_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_roles_is_active ON public.user_roles USING btree (is_active);


--
-- Name: ix_user_roles_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_user_roles_name ON public.user_roles USING btree (name);


--
-- Name: ix_user_sessions_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_is_active ON public.user_sessions USING btree (is_active);


--
-- Name: ix_user_sessions_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_token_hash ON public.user_sessions USING btree (token_hash);


--
-- Name: ix_user_sessions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_user_sessions_user_id ON public.user_sessions USING btree (user_id);


--
-- Name: ix_users_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_created_at ON public.users USING btree (created_at);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_is_active ON public.users USING btree (is_active);


--
-- Name: ix_users_last_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_last_login ON public.users USING btree (last_login);


--
-- Name: ix_users_password_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_password_changed_at ON public.users USING btree (password_changed_at);


--
-- Name: ix_users_reset_token; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_reset_token ON public.users USING btree (reset_token);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: ix_users_two_factor_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_users_two_factor_code ON public.users USING btree (two_factor_code);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: approval_requests approval_requests_approver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_approver_id_fkey FOREIGN KEY (approver_id) REFERENCES public.users(id);


--
-- Name: approval_requests approval_requests_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_requests
    ADD CONSTRAINT approval_requests_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.users(id);


--
-- Name: asset_category_permissions asset_category_permissions_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_category_permissions
    ADD CONSTRAINT asset_category_permissions_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: asset_category_permissions asset_category_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.asset_category_permissions
    ADD CONSTRAINT asset_category_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: device_otp device_otp_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_otp
    ADD CONSTRAINT device_otp_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: failed_login_attempts failed_login_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.failed_login_attempts
    ADD CONSTRAINT failed_login_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: furniture_equipment_transfers furniture_equipment_transfers_furniture_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.furniture_equipment_transfers
    ADD CONSTRAINT furniture_equipment_transfers_furniture_equipment_id_fkey FOREIGN KEY (furniture_equipment_id) REFERENCES public.furniture_equipment(id) ON DELETE CASCADE;


--
-- Name: ict_asset_transfers ict_asset_transfers_ict_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ict_asset_transfers
    ADD CONSTRAINT ict_asset_transfers_ict_asset_id_fkey FOREIGN KEY (ict_asset_id) REFERENCES public.ict_assets(id);


--
-- Name: mfa_secrets mfa_secrets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_secrets
    ADD CONSTRAINT mfa_secrets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: office_equipment_transfers office_equipment_transfers_office_equipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.office_equipment_transfers
    ADD CONSTRAINT office_equipment_transfers_office_equipment_id_fkey FOREIGN KEY (office_equipment_id) REFERENCES public.office_equipment_register(id);


--
-- Name: plant_machinery_transfers plant_machinery_transfers_plant_machinery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plant_machinery_transfers
    ADD CONSTRAINT plant_machinery_transfers_plant_machinery_id_fkey FOREIGN KEY (plant_machinery_id) REFERENCES public.plant_machinery(id);


--
-- Name: portable_item_transfers portable_item_transfers_portable_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portable_item_transfers
    ADD CONSTRAINT portable_item_transfers_portable_item_id_fkey FOREIGN KEY (portable_item_id) REFERENCES public.portable_items(id);


--
-- Name: refresh_tokens refresh_tokens_replaced_by_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_replaced_by_token_id_fkey FOREIGN KEY (replaced_by_token_id) REFERENCES public.refresh_tokens(id) ON DELETE SET NULL;


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_refresh_token_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_refresh_token_id_fkey FOREIGN KEY (refresh_token_id) REFERENCES public.refresh_tokens(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_parent_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_parent_role_id_fkey FOREIGN KEY (parent_role_id) REFERENCES public.user_roles(id);


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

